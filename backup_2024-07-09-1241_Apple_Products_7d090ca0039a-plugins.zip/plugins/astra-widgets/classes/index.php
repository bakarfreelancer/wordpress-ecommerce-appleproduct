<?php
/**
 * Index file
 *
 * @package Astra Addon
 * @since 1.6.0
 */

/* Silence is golden, and we agree. */
