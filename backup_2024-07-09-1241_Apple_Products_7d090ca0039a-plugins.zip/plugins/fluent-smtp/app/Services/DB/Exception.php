<?php namespace FluentMail\App\Services\DB;

class Exception extends \Exception
{

}
