<div class="footer pt70 pb110">
    <div class="dc-row">
        <div class="dc-col-lg-9">
            <div class="footer__content">
                <?php
                include DC_PLUGIN_VIEWS_PATH . 'partials/_menu.php';
                ?>
            </div>
        </div>
    </div>
</div>